using Inventory.Client;
using Inventory.Client.Services;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// =====================================================================
//  پیکربندی چند-سروری (تک‌فایل): همهٔ آدرس‌های API از
//  wwwroot/appsettings.json ← بخش «ApiEndpoints» خوانده می‌شوند.
//  هر ماژول می‌تواند به سرور متفاوتی وصل شود (نگاشت در «Modules»).
//  جزئیات، کلیدهای ماژول و نمونه‌های چندسروره: CONFIG-APIS.md
// =====================================================================
builder.Services.AddSingleton(sp =>
    new ApiClientResolver(builder.Configuration, sp.GetRequiredService<IAuthState>()));

// ApiOptions پیش‌فرض — مصرف‌کننده‌هایی که مستقیم تزریق می‌کنند (داشبوردهای زنده/سخت‌افزار)
builder.Services.AddSingleton(sp =>
    sp.GetRequiredService<ApiClientResolver>().SnapshotOf("Default"));

// HttpClient پیش‌فرض — Endpoint پیش‌فرض؛ آدرس نهایی لحظهٔ اولین استفاده حل می‌شود
// (قبلاً هاردکد به http://localhost:5100 بود — حالا از کانفیگ)
builder.Services.AddScoped(sp =>
{
    var r = sp.GetRequiredService<ApiClientResolver>();
    return new HttpClient { BaseAddress = new Uri(r.BaseUrlOf("Default").TrimEnd('/') + "/") };
});

builder.Services.AddSingleton<IAuthState, AuthState>();

// ApiClient پیش‌فرض (Endpoint پیش‌فرض) — مصرف‌کننده‌های عمومی و صفحات
builder.Services.AddScoped<IApiClient>(sp =>
    sp.GetRequiredService<ApiClientResolver>().For("Default"));

// ---------- ثبت سرویس‌ها با اینترفیس (DIP) + اتصال هر ماژول به API خودش ----------
// کلید ماژول هر سرویس در همین‌جا ثابت است؛ آدرس سرورش از appsettings.json می‌آید.
static void AddModule<TIf, TImpl>(IServiceCollection services, string module)
    where TIf : class where TImpl : class, TIf
    => services.AddScoped<TIf>(sp => (TIf)ActivatorUtilities.CreateInstance(
        sp, typeof(TImpl), sp.GetRequiredService<ApiClientResolver>().For(module)));

AddModule<IAuthApi, AuthApi>(builder.Services, "Auth");                     // ورود/کاربران/نقش‌ها
AddModule<ISettingsService, SettingsService>(builder.Services, "Core");
AddModule<IReferrerService, ReferrerService>(builder.Services, "Core");
AddModule<ICategoryService, CategoryService>(builder.Services, "Inventory");
AddModule<IUnitService, UnitService>(builder.Services, "Inventory");
AddModule<IProductService, ProductService>(builder.Services, "Inventory");
AddModule<IWarehouseService, WarehouseService>(builder.Services, "Inventory");
AddModule<IPartyService, PartyService>(builder.Services, "Inventory");
AddModule<IStockService, StockService>(builder.Services, "Inventory");
AddModule<IOrderService, OrderService>(builder.Services, "Sales");
AddModule<IReportService, ReportService>(builder.Services, "Reports");
AddModule<IDashboardService, DashboardService>(builder.Services, "Reports");
AddModule<IRepairService, RepairService>(builder.Services, "Maintenance");
AddModule<IExpenseService, ExpenseService>(builder.Services, "Finance");
// ---------- ماژول مدیریت پروژه‌ها ----------
AddModule<IKarfarmaService, KarfarmaService>(builder.Services, "Projects");
AddModule<ITypeFactorService, TypeFactorService>(builder.Services, "Projects");
AddModule<IProjectService, ProjectService>(builder.Services, "Projects");
AddModule<IProjectCartableService, ProjectCartableService>(builder.Services, "Projects");
AddModule<IReportWorkService, ReportWorkService>(builder.Services, "Projects");

builder.Services.AddSingleton<IToastService, ToastService>();
builder.Services.AddSingleton<LayoutState>();
builder.Services.AddSingleton<RealtimeService>(); // هسته‌ی بلادرنگ سراسری (SignalR) — Endpoint ماژول «Realtime»

var host = builder.Build();

// تعیین آدرس «همان مبدأ» در زمان اجرا (پشتیبانی از پیش‌نمایش ابری و localhost)
// و تزریق آن به حل‌کننده — Endpointهایی که BaseUrl خالی دارند از این مقدار استفاده می‌کنند.
var js = host.Services.GetRequiredService<Microsoft.JSInterop.IJSRuntime>();
var resolver = host.Services.GetRequiredService<ApiClientResolver>();
var sameOrigin = await js.InvokeAsync<string>("inventoryApiBase", new object[] { resolver.BaseUrlOf("Default") });
resolver.SetSameOrigin(sameOrigin);

// بازیابی نشست ورود از localStorage
await host.Services.GetRequiredService<IAuthState>().InitializeAsync();

await host.RunAsync();
