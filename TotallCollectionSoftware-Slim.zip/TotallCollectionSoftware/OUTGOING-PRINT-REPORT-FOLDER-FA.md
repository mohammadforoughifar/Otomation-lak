# ریشه‌یابی «چاپ نامهٔ صادره درست انجام نمی‌شود» — مسیر `Report/outgoingletter`

تاریخ بررسی: ۱۴۰۵/۰۸/۰۶ (2026-10-28) — دامنه: نامهٔ صادره (`OutgoingLetters`) روی سربرگ شرکت، A4 و A5.

## ۱) پاسخ کوتاه: مشکل خودِ `Report/outgoingletter` این است که «مسیر اجرا» نیست

هیچ‌جای کد این پوشه را نمی‌خواند. جست‌وجوی کل مخزن برای `Report/outgoingletter` در کد
(`*.cs`, `*.razor`, `*.json`, `*.csproj`) هیچ نتیجه‌ای ندارد؛ تنها ارجاع‌ها به مسیر دیگری است:

```text
inventory/src/Inventory.Api/Reports/OutgoingLetters/Companies/{CompanyId}/Outgoing-{A4|A5}.mrt
```

* این مسیر در `Inventory.Api.csproj` با `Content Include="Reports/**/*.mrt"` کنار خروجی
  Build/Publish کپی می‌شود و `FindCompanyTemplate` آن را از ContentRoot / BaseDirectory /
  پوشهٔ جاری می‌جوید (ریشه از `Reporting:Stimulsoft:TemplateRoot`).
* پس هر ویرایش در `Report/outgoingletter/**` (طرح MRT، تصویر سربرگ، فونت) **بی‌اثر** است.
* `Report/outgoingletter/{3,1003}/index.html` هم پیش‌نمایش مرورگری است، نه خروجی چاپ؛ سه لینک
  PDF آن (`Report_A5_OutgoingLetter_Preview.pdf`، `Report_A4_OutgoingLetter_Preview.pdf`،
  `Preview_OutgoingLetter_Company*_A5_A4.pdf`) در مخزن وجود ندارند و ۴۰۴ می‌دهند.

## ۲) حتی با ویرایش مسیر درست، بخشی از MRT اصلاً اعمال نمی‌شود

سرور قالب Stimulsoft را «اجرا» نمی‌کند؛ چاپ با QuestPDF ساخته می‌شود. از هر MRT فقط این‌ها خوانده
می‌شد: `Watermark/ImageBytes` (تصویر سربرگ). کادرهای متنی قالب — `GirandeAsli`، `TitleLetter`،
`TextLetter`، جای تصویر امضاها — در چاپ اعمال نمی‌شدند و چیدمان متن/موضوع/گیرنده/امضا را کد
`OutgoingLetterPrintService` می‌ساخت. بنابراین «جابه‌جا کردن کادرها در قالب» انتظار درستی نداشته.

## ۳) باگ واقعی چاپ: چیدمان فقط برای دو شناسه کالیبره شده بود

در `OutgoingLetterPrintService` (نسخهٔ `inventory/src`) شاخه‌های چیدمان چنین بودند:

```csharp
var isHomepaLetterhead = hasLetterhead && letterheadCompanyId == HomepaCompanyId;   // 1003
var isAriaLetterhead   = hasLetterhead && letterheadCompanyId == AriaCompanyId;     // 1005
```

هر شرکت دیگری به شاخهٔ عمومی می‌افتاد که مقدارها را **سفید** و با فاصله‌های ثابت می‌نوشت.
پیامد اندازه‌گیری‌شده روی تصویر سربرگ‌های موجود در مخزن:

| شرکت | طرح تصویر | رفتار قبلی کد | نتیجه |
|---|---|---|---|
| `1003` | هومپا (نوار آبی) | شاخهٔ کالیبره‌شدهٔ هومپا | درست |
| `3` | **همان طرح هومپا** (تصویر `homepa_company3_letterhead.png` بایت‌به‌بایت همان `…1003…png` است) | شاخهٔ عمومی: مقدار سفید، `PaddingTop 60` | مقدارها ~۲۱pt **پایین‌تر از برچسب‌ها** (برچسب‌های تصویر در ۶۲٫۶/۸۰٫۴/۹۹٫۴pt هستند و مقدارها روی ۸۴/۱۰۲/۱۲۰ می‌افتادند) و متن نامه از ۲۱۴pt شروع می‌شد در حالی که طرح تا ۲۳۲pt ادامه دارد؛ یعنی متن روی تزئینات پایین نوار |
| `1`, `2` | فروغ آریا (کاغذ سفید، برچسب‌های تیره) | شاخهٔ عمومی: مقدار **سفید** روی کاغذ سفید | شماره/تاریخ/پیوست عملاً نامرئی |
| `1005` | آریا همیار ژنراتور | شاخهٔ کالیبره‌شدهٔ آریا | درست |

قالب هر شرکت خودش دقیقاً گفته مقدارها کجا و با چه رنگی باشند:

```xml
<!-- Companies/3/Outgoing-A4.mrt (طرح هومپا) -->
<ClientRectangle>-0.19,0.45,1.14,0.2</ClientRectangle><TextBrush>White</TextBrush>   <!-- شماره -->
<!-- Companies/1/Outgoing-A4.mrt (طرح فروغ) -->
<ClientRectangle>0,0.3,0.9,0.2</ClientRectangle><TextBrush>Black</TextBrush>          <!-- شماره -->
```

کد این اطلاعات را نادیده می‌گرفت. ضمناً دو درخت کد موازی وجود دارد و اسکریپت‌های استقرار با هم
اختلاف دارند:

| اسکریپت | درختی که منتشر می‌کند |
|---|---|
| `publish-server.bat`، `deploy-single.ps1`، `rebuild.ps1` (ریشه) | `src/Inventory.Api` (نسل قدیمی چاپ) |
| `inventory/publish-server.bat`، `inventory/deploy-single.ps1`، `inventory/start.bat` | `inventory/src/Inventory.Api` (نسل جاری) |

## ۴) چه چیزی اصلاح شد

### ۴-۱. مقدارهای شماره/تاریخ/پیوست از قالب خود شرکت خوانده می‌شوند
فایل جدید: `Services/Office/Outgoing/LetterheadMetaFields.cs` (در هر دو درخت `inventory/src` و `src`)

* سه جزء متنی قالب را با عبارت‌های `{DataSource1.LetterNumber}`، `{DataSource1.DateShams}` و
  `{DataSource1.Peyvast}` پیدا می‌کند و از هر کدام می‌خواند: `ClientRectangle` (+ `Margins` صفحه
  و `ReportUnit`)، `TextBrush` (رنگ)، `Font` (اندازه و توپُر بودن) و `HorAlignment`.
* محاسبهٔ مختصات: `(Margin + ClientRectangle) × UnitToPoints` — همان قراردادی که مختصات
  کالیبره‌شدهٔ هومپا/آریا از آن ساخته شده بود. برای هومپا خروجی این محاسبه **عیناً** همان اعداد
  `HomepaLetterheadLayout` است (۱۴٫۴/۶۰٫۴۸ …)، پس رفتار ۱۰۰۳ تغییر نمی‌کند.
* اگر قالب موجود نباشد یا این سه جزء را اعلام نکند، `null` برمی‌گردد و چیدمان قبلی دست‌نخورده
  اجرا می‌شود (بدون رگرسیون برای شرکت‌هایی که فقط فایل سربرگ ثبت‌شده دارند).

### ۴-۲. شاخهٔ عمومی هدر از همین اعلان‌ها استفاده می‌کند
در `BuildContentPdf`، شاخهٔ `else if (hasLetterhead)`:

```csharp
var declared = ReadDeclaredMetaFields(FindCompanyTemplate(...));
if (declared != null) { /* AddDeclaredField: مستطیل/رنگ/فونت/تراز از قالب */ }
else { /* چیدمان قبلی، بدون تغییر */ }
```

`pageTopMargin` هم به‌صورت متغیر مشترک با `page.MarginTop` محاسبه می‌شود، چون `page.Header()`
بعد از حاشیهٔ بالا شروع می‌شود و مختصات قالب «مطلق» است. مقادیر منفی (مستطیلی که کمی بالاتر از
حاشیه است، مثل تاریخ در قالب شرکت ۱) با `Math.Max(0, …)` مهار می‌شوند تا QuestPDF خطا ندهد.
نتیجهٔ عملی: `1`, `2` سیاه و روی خط‌چین خودشان، `1005` و `1003` مثل قبل.

### ۴-۳. شناسهٔ هومپا فقط ۱۰۰۳ نیست
```csharp
private static readonly int[] DefaultHomepaCompanyIds = { 3, HomepaCompanyId };
private static readonly int[] DefaultAriaCompanyIds   = { AriaCompanyId };
```
و قابل تنظیم بدون بیلد، در `appsettings.json`:

```json
"Reporting": {
  "OutgoingLetters": {
    "HomepaCompanyIds": "3,1003",
    "AriaCompanyIds": "1005"
  }
}
```

چون `Reports/OutgoingLetters/Companies/3` و `/1003` هر دو همان تصویر هومپا را دارند، شرکت ۳ با
همان چیدمان کالیبره‌شده (مقدار سفید روی نوار، فاصلهٔ ۸۰/۲۸ برای شروع متن، رزرو پانوشت، شمارهٔ
صفحه، پس‌زمینهٔ شفاف) چاپ می‌شود.

### ۴-۴. پوشهٔ `Report/outgoingletter`
* `Report/outgoingletter/README-FA.md` اضافه شد: این پوشه بستهٔ طراحی/پیش‌نمایش است، مسیر اجرا
  کجاست، هر شناسه چه طرحی دارد و مراحل اعمال یک تغییر طراحی چیست.
* لینک‌های PDF شکسته از `index.html` حذف و به یک یادداشت جایگزین شد؛ عنوان صفحهٔ ۱۰۰۳ هم که
  اشتباهاً «قالب‌های شرکت ۳» بود اصلاح شد.
* خود فایل‌های MRT و تصویرهای این پوشه دست‌نخورده‌اند.

نکته: `Report/outgoingletter/1003/*.mrt` با نسخهٔ **قدیمی‌تر** `src/Inventory.Api/Reports/.../1003`
یکی است (۴۶۶٬۶۴۵ بایت تصویر) و با `inventory/.../1003` (۴۷۳٬۴۹۳ بایت) یکی نیست؛
`Report/outgoingletter/3/*` برابر `inventory/.../3` است. یعنی این پوشه آینهٔ دو درخت مختلف است.

### ۴-۵. ریشهٔ سوم (مهم‌ترین علت «طرح شرکت دیگر»): شناسهٔ عددی شرکت

قالب با شمارهٔ پوشه پیدا می‌شود (`Companies/{CompanyId}`) و این شماره بین نصب‌ها یکی نیست.
`SystemCompanies` شناسه را خودکار می‌سازد، پس در نصب تازه شرکت‌ها `1`,`2`,`3` می‌شوند و پوشه‌های
موجود این طرح‌ها را دارند:

| پوشه | طرح داخل تصویر |
|---|---|
| `1`, `2` | فروغ آریا |
| `3` | هومپا |
| `1003` | هومپا (نسخهٔ دیگر تصویر، همان جای برچسب) |
| `1005` | آریا همیار ژنراتور |

یعنی اگر شرکتِ واقعیِ شما هومپا باشد ولی شناسه‌اش `1` باشد، نامه روی **سربرگ فروغ آریا** چاپ
می‌شود و هیچ خطایی هم دیده نمی‌شود؛ و اگر شناسه `4` یا `6` باشد، چاپ با «سربرگ پیدا نشد» متوقف
می‌شود. آزمون سریع (`simulated search order`) روی هر شناسه این را نشان می‌دهد؛ برای `999` هیچ
قالبی پیدا نمی‌شود.

### اصلاح
* `FindCompanyTemplate` اکنون اول «طرح نگاشت‌شده» و بعد پوشهٔ هم‌نام خود شرکت را می‌جوید:

```csharp
foreach (var designId in DesignCompanyIds(companyId)) { ... }
```

* نگاشت در `appsettings.json` و بدون بیلد:

```json
"Reporting": { "OutgoingLetters": { "CompanyTemplateMap": { "4": "1003" } } }
```

* انتخاب چیدمان (ارتفاع هدر، شروع بدنه، رزرو پانوشت، رنگ/جای مقدارها) هم از **طرح** پیروی می‌کند،
  نه شناسهٔ خام: `designCompanyId = TemplateDesignId(letterheadCompanyId)`. پس یک نگاشت، تمام
  رفتار چاپ را یک‌جا درست می‌کند. بدون نگاشت، رفتار دقیقاً مثل قبل است.
* هنگام استفاده از نگاشت، یک خط `LogInformation` مسیر و طرح انتخابی را ثبت می‌کند.

### ۴-۶. ابزار همگام‌سازی برای خودِ پوشهٔ `Report/outgoingletter`

`Report/outgoingletter/sync-to-api-templates.bat` فایل‌های `Report_{A4,A5}_OutgoingLetter.mrt`
را برای شرکت‌های `3` و `1003` به مسیر واقعی چاپ در هر دو درخت کد کپی می‌کند
(`sync-to-api-templates.bat inventory|src` برای یکی از دو درخت). قبلاً برای اعمال یک تغییر طراحی
باید مسیرها را دستی می‌شناختید؛ اکنون یک فرمان کافی است.

### ۴-۷. علامت اصلی شما: «صفحهٔ چاپ در حال بارگذاری می‌ماند و بعد خطا می‌دهد»

این علامت یک باگ چیدمان نبود، بلکه **سقف زمانی کلاینت** بود. در `LetterPrintWorkflow` یک
مهلت ثابت **۱۵ ثانیه** برای مجموع دو کار وجود داشت: «دریافت PDF از سرور» و «تحویل PDF به
مرورگر». ساخت PDF روی سربرگ برای اولین چاپ (خواندن قالب چند مگابایتی، ثبت فونت، رندر
QuestPDF برای متن و سپس PDFsharp روی تصویر سربرگ ۲۴۸۱×۳۵۰۸) از ۱۵ ثانیه می‌گذشت؛ درخواست
قطع می‌شد، پنجره قرمز «خطا» می‌شد و در همان لحظه سرور داشت رندر را تمام می‌کرد. برای همین
هر بار «چاپ آماده نمی‌شد».

اصلاح‌ها (در **هر دو** درخت `src/` و `inventory/src/`):

| موضوع | قبل | بعد |
|---|---|---|
| مهلت دریافت | ۱۵ ثانیه، مشترک با تحویل | ۹۰ ثانیه (تلاش اول) / ۶۰ ثانیه (تلاش مجدد) |
| مهلت تحویل به مرورگر | از همان ۱۵ ثانیه کم می‌شد | ۳۰ ثانیهٔ جدا |
| بازخورد به کاربر | فقط «در حال آماده‌سازی» تا لحظهٔ خطا | بعد از ۸ ثانیه: «در حال ساخت PDF روی سربرگ شرکت…» (`window.ltxPrintStatus`) |
| تکرار رندر در «تلاش مجدد» | هر بار از صفر | کش رندر ۹۰ ثانیه‌ای روی سرور (کلید = SHA-256 دادهٔ مؤثر نامه) |
| خطای غیرمنتظرهٔ سرور | `500` خالی | `500` با متن علت + `LogError` با شناسهٔ نامه |
| فونت فارسی غایب | بی‌صدا نادیده گرفته می‌شد | خطای صریح با مسیر فایل |

جزئیات فنی که در تست‌ها قفل شده‌اند:

* کلید کش: `outgoing-print-v2:` + `SHA256(letterId, size, flags, companyId, شماره‌ها, تاریخ‌ها,`
  `عنوان/متن/گیرنده, تعداد و وضعیت امضاها, تعداد رونوشت, تعداد پیوست)`؛ با هر ویرایش نامه کلید
  عوض می‌شود، پس چاپِ بعدی هرگز نسخهٔ کهنه نمی‌دهد.
* درخواست‌های هم‌زمان (مثلاً دوبار کلیک) یک رندر را با هم استفاده می‌کنند: رکورد کش پیش از
  شروع رندر منتشر می‌شود و همه فقط `await` می‌کنند
  (`CachedRender` بر پایهٔ `TaskCompletionSource<byte[]?>` با
  `TaskCreationOptions.RunContinuationsAsynchronously` — **نه** `Lazy<Task<T>>`؛ دلیل در بخش ۴-۹).
* خروجی `null` و هر استثنا از کش حذف می‌شود؛ خطا هرگز کش نمی‌شود.
* PDF به‌صورت **باینری (Uint8Array)** به مرورگر می‌رود، نه base64؛ در نتیجه حجم انتقال و زمان
  آماده‌سازی کمتر است.

**کدام درخت منتشر می‌شود؟** اسکریپت‌های ریشهٔ مخزن (`publish-server.bat`، `deploy-single.*`،
`RUN.ps1`) `src/` را منتشر می‌کنند و `inventory/publish-server.bat` مسیر `inventory/src/` را.
قبلاً اصلاحات فقط در `inventory/` بود؛ اکنون `src/Inventory.Client` هم همان
`LetterPrintWorkflow` را دارد، همان سطح JS چاپ (`ltxPrintBegin/Ready/Fail/Status/WaitForAction/`
`DirectPage/Cancel`) و همان کش/خطای سرور در `src/Inventory.Api`. چهار صفحهٔ چاپ (نامهٔ داخلی،
کارتابل صادره، نمایش نامه، دبیرخانه) در هر دو درخت از همین سرویس مشترک استفاده می‌کنند.

### ۴-۸. «سربرگ‌های طراحی‌شده در `Reports/OutgoingLetters/Companies` خوانده نمی‌شوند»

طرح‌ها همان‌جا هستند و فایل‌ها هم با بیلد منتشر می‌شوند؛ پس مشکل در مسیر فایل نیست، در
**انتخاب شرکت و انتخاب منبع** است. سه علت که هر سه در کد پیدا و اصلاح شدند:

| # | علت | چه اتفاقی می‌افتاد |
|---|---|---|
| ۱ | **اولویت فایل ثبت‌شده** | `letterheadPath = registeredPath ?? templateLetterheadPath` — اگر روی رکورد شرکت (`SystemCompanies.LetterheadFileName`) فایلی ثبت شده باشد (مثل `wwwroot/uploads/letterheads/homepa_company1003_letterhead.jpg`)، طرح داخل MRT **هرگز خوانده نمی‌شد**. |
| ۲ | **نامهٔ بدون شرکت (CompanyId = NULL)** | در فرم نامه، کمبوی «شرکت صادرکننده» فقط «شرکت فعال» را نشان می‌داد و پیش‌فرضش `0` («بدون شرکت») بود. اگر شرکت فعال قابل تشخیص نبود (کاربر بدون ردیف دسترسی شرکت)، هیچ شرکتی قابل انتخاب نبود و نامه با `CompanyId = NULL` ذخیره می‌شد. در چاپ، «اولین شرکت فعالِ دارای سربرگ» انتخاب می‌شد؛ یعنی نامه روی طرح **شرکت دیگر** چاپ می‌شد. |
| ۳ | **نام فایل قالب** | فقط `Outgoing-A4.mrt` / `Outgoing-A5.mrt` با همان حروف دقیق خوانده می‌شد؛ فایلی با نام دیگر (مثلاً `Report_A4_OutgoingLetter.mrt`) بی‌صدا نادیده می‌رفت و علتش هم فقط در سطح `Debug` لاگ می‌شد (یعنی در سطح پیش‌فرض `Information` هیچ اثری نداشت). |

#### اصلاح‌ها

1. **انتخاب شرکت**
   * فرم نامه: همهٔ شرکت‌های فعال در کمبو می‌آیند و پیش‌فرض «شرکت فعال» کاربر است
     (`CompanyOptions` در `ComposeOutgoingModal.razor`).
   * سرور: اگر کلاینت شرکتی نفرستد، `CompanyId` نامه با «شرکت فعالِ همان درخواست»
     (`X-Company-Id` اعتبارسنجی‌شده) پر می‌شود — نه `NULL`
     (`DefaultCompanyIdForLetter` در `OutgoingLetterService`). ویرایش نامه هم دیگر
     `CompanyId` را پاک نمی‌کند.
2. **انتخاب منبع سربرگ (پیکربندی)**
   * کلید تازه: `Reporting:OutgoingLetters:PreferTemplateLetterhead`
     (`false` = رفتار قبلی، `true` = طرح پوشهٔ `Companies` اولویت دارد).
   * اگر فایل ثبت‌شده بر طرح مقدم باشد، یک خط `Information` می‌گوید کدام فایل برنده شد و
     چطور می‌توان طرح را مقدم کرد.
3. **یافتن فایل قالب**
   * اگر نام فایل استاندارد نباشد: جست‌وجوی بی‌توجه به بزرگی/کوچکی حروف، سپس نامی که
     `A4`/`A5` در آن آمده، و اگر تنها یک `.mrt` در پوشه باشد همان استفاده می‌شود (با لاگ).
   * اگر هیچ قالبی پیدا نشد: **`LogWarning`** با `TemplateRoot`، همهٔ مسیرهای جست‌وجو و
     فهرست پوشه‌های طرح موجود (`AvailableDesigns`).
4. **نامهٔ بی‌شرکت در نصب چندشرکتی**
   * دیگر سربرگ «اولین شرکت» یا «فوروث» را نمی‌گیرد؛ اگر نتوان شرکت را از شرکت فعال یا
     تک‌شرکتی بودن تشخیص داد، چاپ با پیام فارسی روشن متوقف می‌شود.
5. **تشخیص چاپ (ابزار تازه)**
   * دکمهٔ «تشخیص چاپ (چرا سربرگ درست نیست؟)» در منوی چاپ صفحهٔ نامه.
   * معادل API: `GET api/outgoing-letters/{id}/print/diagnose?size=A4` (فقط دبیرخانه/مدیر).
   * خروجی: `letterCompanyId`، `effectiveCompanyId`، `companySource`، `templateDesignId`
     (با اعمال `CompanyTemplateMap`)، `templatePath`، `templateImageBytes`،
     `registeredLetterheadPath`، `preferTemplateLetterhead`، `letterheadSource`
     (`Template`/`Registered`/`None`)، `availableDesigns` و `hint` (جملهٔ فارسی علت).

#### سه بررسی سریع روی سرور (پیش از هر تغییر کد)

```sql
-- ۱) نام و سربرگ ثبت‌شدهٔ شرکت‌ها
SELECT Id, Name, IsActive, LetterheadFileName FROM SystemCompanies ORDER BY Id;

-- ۲) نامه‌هایی که شرکت ندارند (علت شمارهٔ ۲)
SELECT COUNT(*) AS NoCompany FROM OutgoingLetters WHERE CompanyId IS NULL;

-- ۳) نامه‌های بدون شرکت را به شرکت درست وصل کنید (با پشتیبان‌گیری!)
-- UPDATE OutgoingLetters SET CompanyId = 1003 WHERE CompanyId IS NULL;
```

```text
# ۴) فایل‌های طرح روی سرور (باید کنار Inventory.Api.dll و در پوشهٔ Reports باشند)
<deploy>\Reports\OutgoingLetters\Companies\{CompanyId}\Outgoing-A4.mrt
<deploy>\Reports\OutgoingLetters\Companies\{CompanyId}\Outgoing-A5.mrt
```

اگر می‌خواهید **طرح داخل پوشهٔ Companies مرجع چاپ باشد** (نه فایل ثبت‌شده روی رکورد شرکت):

```jsonc
"Reporting": {
  "OutgoingLetters": {
    "PreferTemplateLetterhead": true
  }
}
```

یا `SystemCompanies.LetterheadFileName` آن شرکت را خالی کنید. برای شرکت آریا (۱۰۰۵) توجه
کنید که فایل ثبت‌شده‌اش یک PDF برداری است و طرح داخل MRT یک تصویر JPEG است؛ اگر کیفیت
برداری را می‌خواهید، همان اولویت پیش‌فرض (`false`) را نگه دارید.

### ۴-۹. خطای ساخت پروژه: `VSTHRD011` روی `Lazy<Task<byte[]?>>`

هنگام اجرا/ساخت پروژه در Visual Studio این خطا گرفته می‌شد:

```text
Error VSTHRD011  Lazy<Task<T>>.Value can deadlock. Use AsyncLazy<T> instead.
File: inventory/src/Inventory.Api/Services/Office/Outgoing/OutgoingLetterPrintService.cs
```

علت: کش رندر چاپ با `Lazy<Task<byte[]?>>` ساخته شده بود و هر دو خواندنِ `cached.Render.Value`
و `render.Value` را داشت. قاعدهٔ `VSTHRD011` (بستهٔ `Microsoft.VisualStudio.Threading.Analyzers`)
این الگو را **خطا** می‌داند، چون کارخانهٔ مقدار، زمینهٔ اولین فراخوان را به ارث می‌برد و اگر آن
زمینه به رشتهٔ اصلی (UI) نیاز داشته باشد، می‌تواند deadlock کند. (توجه: قاعده فقط
`Lazy<T>` با نوع awaitable را می‌گیرد؛ جای دیگری که در همین سرویس `Lazy<CachedLetterheadAsset>`
داریم — کش decode تصویر سربرگ — نه awaitable است و نه در کارخانه‌اش
`JoinableTaskFactory.Run` صدا زده می‌شود، پس مشمول این قاعده نیست.)

**اصلاح:** کش رندر بدون `Lazy` بازنویسی شد و همان رفتار (یک رندر مشترک برای درخواست‌های هم‌زمان)
حفظ شد:

```csharp
private sealed class CachedRender
{
    private readonly TaskCompletionSource<byte[]?> _completion =
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    public CachedRender(DateTime createdUtc) => CreatedUtc = createdUtc;
    public DateTime CreatedUtc { get; }
    public Task<byte[]?> Render => _completion.Task;
    public void Complete(byte[]? pdf) => _completion.TrySetResult(pdf);
    public void Fail(Exception error) => _completion.TrySetException(error);
}
```

و در `GeneratePdfAsync`:

```csharp
var (cached, startedHere) = RentRenderedPdf(cacheKey);   // TryAdd پیش از شروع رندر
if (!startedHere) return await cached.Render;            // فقط await، بدون .Value

try
{
    var pdf = await GeneratePdfCoreAsync(...);
    if (pdf == null) RenderedPdfs.TryRemove(new KeyValuePair<string, CachedRender>(cacheKey, cached));
    cached.Complete(pdf);
    return pdf;
}
catch (Exception ex)
{
    RenderedPdfs.TryRemove(new KeyValuePair<string, CachedRender>(cacheKey, cached));
    cached.Fail(ex);   // همهٔ منتظرانِ همان رندر همان خطا را می‌گیرند
    throw;
}
```

نکته‌های رفتار:

* رکورد **قبل** از رندر در `RenderedPdfs` ثبت می‌شود (`TryAdd`)، پس دوبار کلیک = یک رندر.
* رکورد منقضی با مقایسهٔ **خودِ نمونه** حذف می‌شود
  (`TryRemove(KeyValuePair<...>)`) تا رکورد تازهٔ درخواست دیگری پاک نشود.
* `Fail` باعث می‌شود بقیهٔ درخواست‌های در انتظار به‌جای معلق ماندن، خطای واقعی بگیرند.
* در رقابت شدید (۵ تلاش ناموفق `TryAdd`) بدون کش رندر می‌شود تا درخواست کاربر معلق نماند.
* این تغییر در **هر دو درخت** (`src/` و `inventory/src/`) اعمال شد و یک تست هم اضافه شد که
  وجود `Lazy<Task` را در این سرویس ممنوع می‌کند تا خطای ساخت برنگردد.

### ۴-۱۰. خطای ساخت پروژه: `CS0535` — ناهم‌خوانی امضای `GeneratePdfAsync`

```text
Error CS0535  'OutgoingLetterPrintService' does not implement interface member
'IOutgoingLetterPrintService.GeneratePdfAsync(int, string, bool, bool, bool, bool)'
File: inventory/src/Inventory.Api/Services/Office/Outgoing/OutgoingLetterPrintService.cs
```

علت: سرویس چاپ در دو درخت **دو اینترفیس متفاوت** دارد:

| درخت | امضای اینترفیس |
|---|---|
| `src/` | `GeneratePdfAsync(int letterId, string size, bool withCopy = true)` |
| `inventory/src/` | `GeneratePdfAsync(int letterId, string size, bool withCopy, bool withMargin, bool withLetterhead, bool requireSignatures)` |

هنگام بازنویسی کش رندر (رفع `VSTHRD011`) در هر دو درخت یک امضای سه‌پارامتری نوشته شد؛ در نتیجه
پیاده‌سازیِ درخت `inventory/` دیگر عضو اینترفیس شش‌پارامتری نبود و کامپایلر `CS0535` داد. دو خطای
پنهانِ دیگر هم از همین ریشه بود: `CS0103` برای `withMargin`/`withLetterhead`/`requireSignatures`
و `CS7036` برای فراخوانی `BuildPrintCacheKeyAsync(letterId, size, withCopy)`.

**اصلاح** (فقط درخت `inventory/`):

```csharp
public async Task<byte[]?> GeneratePdfAsync(int letterId, string size, bool withCopy = true,
    bool withMargin = true, bool withLetterhead = true, bool requireSignatures = true)
{
    var cacheKey = await BuildPrintCacheKeyAsync(
        letterId, size, withCopy, withMargin, withLetterhead, requireSignatures);
    ...
    var pdf = await GeneratePdfCoreAsync(
        letterId, size, withCopy, withMargin, withLetterhead, requireSignatures);
```

نکتهٔ مهم دربارهٔ کش: کلید کش باید **همهٔ** گزینه‌های مؤثر در خروجی را ببیند؛ وگرنه نسخهٔ
«با سربرگ» و «بدون سربرگ» (یا «با امضا» و «بدون امضا») خروجی یکدیگر را از کش برمی‌داشتند.

**جلوگیری از تکرار:** یک تست قراردادی اضافه شد که برای هر دو درخت، هر عضو
`IOutgoingLetterPrintService` را با پیاده‌سازی‌اش مقایسه می‌کند (تعداد **و نام** پارامترها) و
همچنین بررسی می‌کند کلید کش همین گزینه‌ها را شامل شود. این تست روی نسخهٔ قبل از اصلاح
(`interface=6, impl=3`) شکست می‌خورد و روی نسخهٔ فعلی سبز است.

## ۵) تست‌ها و بررسی‌هایی که انجام شد

```bash
python3 -m unittest discover -s inventory/tests/OutgoingLetterhead -p 'test_*.py' -v   # ۵۸ تست، OK
```

تست‌های تازه (در همان فایل) این‌ها را قفل می‌کنند:

* هر ده قالب (`1`,`2`,`3`,`1003`,`1005` × `A4`,`A5`) هر سه مقدار را اعلام می‌کنند.
* رنگ اعلام‌شده با طرح تصویر هم‌خوان است: هومپا (`3`,`1003`) سفید، فروغ/آریا (`1`,`2`,`1005`) سیاه.
* هندسهٔ شرکت `3` و `1003` یکسان است.
* اعداد `HomepaLetterheadLayout` با اعلام‌های MRT قابل‌قبول یکسان می‌مانند (جلوگیری از انحراف).
* رندر مقادیر از قالب (و نه حدس سفید) در سورس سرویس وصل شده است.
* چیدمان از «طرح» پیروی می‌کند و جست‌وجوی قالب، اول پوشهٔ نگاشت‌شده را می‌بیند.
* `CompanyTemplateMap` از `appsettings.json` خوانده می‌شود.
* هر پوشهٔ قالب هر دو سایز را دارد، و اسکریپت/فایل‌های همگام‌سازی پوشهٔ `Report/outgoingletter` موجودند.
* بودجهٔ زمانی چاپ: ۹۰/۶۰/۳۰ ثانیه، نبودِ سقف ۱۵ ثانیه‌ای، و بودجهٔ جدا برای تحویل به مرورگر.
* کش رندر: عمر ۹۰ ثانیه، کلید SHA-256 شامل امضا/رونوشت/پیوست، اشتراک رندر هم‌زمان، حذف خطا از کش.
* خطای چاپ به کاربر می‌رسد (`catch (Exception ex)` + متن `ساخت PDF نامه ناموفق بود (...)`) در هر دو درخت.
* فونت فارسی غایب، خطای صریح می‌دهد (نه PDF ناخوانا).
* هر دو درخت کلاینت: ثبت `LetterPrintWorkflow` در `Program.cs`، استفادهٔ چهار صفحه از آن، و کامل بودن
  سطح JS چاپ؛ هیچ صفحه‌ای دیگر PDF را base64 به `ltxPrintReady` نمی‌دهد.
* منبع سربرگ: کلید `PreferTemplateLetterhead` در هر دو درخت و در `appsettings.json`، و لاگ
  «فایل ثبت‌شده بر طرح اولویت دارد».
* یافتن قالب: پذیرش نام‌های غیراستاندارد و هشدار پرحرف (با فهرست پوشه‌های موجود) در نبود قالب.
* نامهٔ بی‌شرکت: نبود انتخاب «اولین شرکت دارای سربرگ» و وجود پیام توقف در نصب چندشرکتی.
* ذخیرهٔ `CompanyId` نامه از روی «شرکت فعال درخواست» در ساخت و ویرایش.
* دسترس‌پذیری تشخیص چاپ: `DiagnoseAsync` + endpoint `print/diagnose` + DTO مشترک +
  دکمهٔ «تشخیص چاپ» و متد کلاینت.
* نبود `Lazy<Task`/`render.Value` در سرویس چاپ (قاعدهٔ `VSTHRD011` ساخت پروژه را می‌شکند)
  و استفادهٔ `TaskCompletionSource<byte[]?>` با `RunContinuationsAsynchronously`.
* هم‌خوانی امضای `GeneratePdfAsync`/`DiagnoseAsync` با اینترفیس در هر دو درخت (جلوگیری از `CS0535`)
  و حضور همهٔ گزینه‌های خروجی در کلید کش.

تصویر سربرگ‌های همهٔ شرکت‌ها جداگانه decode و پیکسل‌به‌پیکسل اندازه‌گیری شد (جای برچسب‌ها و
رنگ متن) تا اعداد بالا از روی تصویر واقعی به دست بیاید، نه از حافظه.

**محدودیت این محیط:** SDK دات‌نت و بسته‌های NuGet (QuestPDF/PDFsharp/Stimulsoft/EF Core) در
این سندباکس موجود نیست، بنابراین `dotnet build` اجرا نشد. تغییرها به‌صورت گرامری با پارسر C#
بررسی شد (بدون خطای نحوی) و منطق خواندن MRT با یک بازسازی مستقل در پایتون روی همان فایل‌ها
آزموده شد؛ اما کامپایل و چاپ واقعی باید روی ماشین شما انجام شود:

```powershell
dotnet build inventory/Inventory.sln -c Debug
dotnet build Inventory.sln -c Debug            # اگر از درخت ریشه استفاده می‌کنید
```

## ۶) اگر بعد از این تغییرها هنوز چاپ درست نبود، به ترتیب این‌ها را ببینید

0. **شناسهٔ شرکت را با پوشهٔ قالب مقایسه کنید** (پیش از هر چیز):
   ```sql
   SELECT Id, Name, IsActive FROM SystemCompanies ORDER BY Id;
   ```
   اگر شناسه در `{1,2,3,1003,1005}` نیست، یا طرحش با طرح شرکت شما فرق دارد، در
   `Reporting:OutgoingLetters:CompanyTemplateMap` نگاشتش کنید (مثال: `"4": "1003"`).
1. **کدام درخت ساخته/منتشر شده؟** اگر با `publish-server.bat` ریشه منتشر می‌کنید، `src/` را
   منتشر می‌کنید. هر دو درخت اصلاح شده‌اند، ولی فایل‌های منتشرشده روی سرور باید تازه باشند.
2. **اگر پنجرهٔ چاپ باز شد ولی «آماده نشد»:** دو لاگ زیر را با هم ببینید (هر دو در سطح Information):
   * کلاینت (کنسول مرورگر / لاگ Blazor): `LetterPrintClientTiming Stage=… StageMs=… TotalMs=…`
     مراحل: `print-surface-ready`، `pdf-download`، `browser-print-handoff`، `complete`؛ در خطا:
     `preparation-failed`، و پیام خطا.
   * سرور (فایل لاگ API): `OutgoingLetterPrintTiming LetterId=… Stage=… StageMs=…`
     مرحله‌های `questpdf-compose-and-render` و `pdfsharp-letterhead-overlay` می‌گویند کدام قسمت
     کند است. اگر مجموع دو مرحله در تلاش اول حدود ۱۰–۲۰ ثانیه است، رفتار فعلی طبیعی است و
     تلاش مجدد به‌خاطر کش رندر تقریباً فوری تمام می‌شود.
   * اگر پاسخ `500` با متن `ساخت PDF نامه ناموفق بود (<نوع خطا>): <متن>` دیدید، همان متن علت
     واقعی است (فونت غایب، امضای ناقص، قالب شرکت، دسترسی دیتابیس).
3. **لاگ قالب/چیدمان** (`OutgoingLetterPrintService`) را بخوانید:
   `LetterCompanyId`، `SelectedCompanyId`، `RegisteredPath`، `TemplatePath`، `FinalPath`،
   `FromTemplate` و خط «مقادیر شماره/تاریخ/پیوست از قالب شرکت خوانده شد».
   اگر `FinalPath` روی `wwwroot/uploads/letterheads/...` است، **فایل ثبت‌شده بر قالب MRT اولویت
   دارد**؛ برای استفاده از طرح داخل MRT باید `SystemCompanies.LetterheadFileName` خالی شود.
4. **قالب روی سرور هست؟** پوشهٔ `Reports/OutgoingLetters/Companies/{id}` باید کنار فایل اجرایی
   API باشد (csproj آن را کپی می‌کند؛ انتقال دستی فایل‌ها کافی نیست).
5. **کش‌ها:** تصویر سربرگ در `%TEMP%/totall-letterheads` (کلید = طول و زمان تغییر فایل) و خروجی
   چاپ تا ۹۰ ثانیه در حافظهٔ API. برای دیدن اثر تغییر قالب، ۹۰ ثانیه صبر کنید یا سرویس API را
   ری‌استارت کنید؛ حذف فایل کش سربرگ هم امن است.
6. **گیت‌های چاپ** (اگر پیام خطا می‌گیرید، نه خروجی غلط): مجوز دبیرخانه/ایجادکننده/دریافت‌کننده،
   کامل بودن امضاها، و وجود `Resources/fonts/Vazirmatn-Regular.ttf` کنار API — این مورد دیگر
   بی‌صدا نادیده گرفته نمی‌شود و پیام صریح می‌دهد.

## ۷) پیشنهادهای بعدی (انجام نشده)

* یکی از دو درخت کد (`src/` یا `inventory/src/`) حذف/آرشیو شود تا اسکریپت‌های استقرار نتوانند
  نسخهٔ قدیمی را منتشر کنند.
* چیدمان متن/موضوع/گیرنده هم از قالب خوانده شود (همان کاری که برای سه مقدار انجام شد) تا کل طرح
  MRT مرجع چاپ باشد.
* اگر می‌خواهید `Report/outgoingletter` واقعاً مرجع باشد، `Reporting:Stimulsoft:TemplateRoot` را
  به مسیر مطلق همان پوشه تنظیم کنید (یا فایل‌ها را به مسیر اجرا کپی کنید) — با یک مرجع، نه دو.
