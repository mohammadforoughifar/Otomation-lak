using System.ComponentModel.DataAnnotations;

namespace Inventory.Api.Data;

/// <summary>
/// لاگ ممیزی (Audit) ماژول مدیریت پروژه — هر رویداد مهم روی پروژه اینجا ثبت می‌شود:
/// ثبت/ویرایش/حذف پروژه، ثبت یا ویرایش فاکتور، تایید/رد مدیر، اتمام کارشناسی، آپلود/حذف پیوست.
/// </summary>
public class ProjectLog
{
    public int Id { get; set; }

    public int ProjectId { get; set; }

    /// <summary>کد پروژه در لحظه رویداد (برای نمایش حتی اگر بعداً تغییر کند)</summary>
    [MaxLength(60)] public string ProjectCode { get; set; } = "";

    /// <summary>اکشن ماشینی: Create / Update / Delete / Factor / Approve / Reject / ExpertDone / AttachAdd / AttachDelete</summary>
    [MaxLength(30)] public string Action { get; set; } = "";

    /// <summary>عنوان فارسی رویداد — مثل «ویرایش اطلاعات پروژه»</summary>
    [MaxLength(120)] public string ActionFa { get; set; } = "";

    /// <summary>شرح تغییر (مثلاً فیلدهای قبل ← بعد یا نام فایل پیوست)</summary>
    [MaxLength(1000)] public string? Detail { get; set; }

    /// <summary>کاربر انجام‌دهنده</summary>
    public int ActorUserId { get; set; }

    [MaxLength(150)] public string ActorName { get; set; } = "";

    public DateTime At { get; set; } = DateTime.Now;
}
