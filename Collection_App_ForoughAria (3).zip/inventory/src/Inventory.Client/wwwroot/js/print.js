// =====================================================================
// چاپ سند جدولی — روش IFRAME مخفی (بدون پاپ‌آپ — با مسدودکننده‌ها هم کار می‌کند)
// opt = { title, subTitle, meta:[...], headers:[...], rows:[[...]], footerTotal, printedAt, printedBy }
// =====================================================================
window.printTableReport = function (opt) {
    opt = opt || {};
    var esc = function (s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    };

    var meta = (opt.meta || []).map(function (m) { return '<span class="chip">' + esc(m) + '</span>'; }).join('');
    var head = (opt.headers || []).map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('');
    var body = (opt.rows || []).map(function (r) {
        return '<tr>' + r.map(function (c, i) {
            return '<td class="' + (i === r.length - 1 ? 'desc' : 'num') + '">' + esc(c) + '</td>';
        }).join('') + '</tr>';
    }).join('');
    var foot = opt.footerTotal
        ? '<tfoot><tr><td colspan="' + ((opt.headers || []).length) + '">' + esc(opt.footerTotal) + '</td></tr></tfoot>'
        : '';

    var html =
        '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8" />' +
        '<title>' + esc(opt.title || 'گزارش') + '</title>' +
        '<style>' +
        '  * { box-sizing: border-box; }' +
        '  body { font-family: Tahoma, "Segoe UI", sans-serif; color: #1e293b; margin: 0; padding: 18px 22px; font-size: 11.5px; }' +
        '  .brand { display: flex; justify-content: space-between; align-items: baseline; border-bottom: 2.5px solid #4f46e5; padding-bottom: 8px; margin-bottom: 12px; }' +
        '  .brand .sys { font-size: 10px; color: #64748b; }' +
        '  h1 { font-size: 19px; margin: 0; color: #312e81; }' +
        '  .sub { font-size: 13px; color: #475569; margin: 2px 0 10px; font-weight: 700; }' +
        '  .chips { margin-bottom: 12px; line-height: 2.1; }' +
        '  .chip { display: inline-block; background: #eef2ff; border: 1px solid #c7d2fe; color: #3730a3; border-radius: 999px; padding: 1px 12px; margin-left: 6px; font-size: 10.5px; font-weight: 700; }' +
        '  table { width: 100%; border-collapse: collapse; }' +
        '  th { background: #312e81; color: #fff; font-weight: 700; padding: 6px 7px; border: 1px solid #312e81; font-size: 11px; white-space: nowrap; }' +
        '  td { border: 1px solid #cbd5e1; padding: 5px 7px; vertical-align: top; }' +
        '  td.num { text-align: center; white-space: nowrap; }' +
        '  td.desc { text-align: right; }' +
        '  tbody tr:nth-child(even) td { background: #f8fafc; }' +
        '  tfoot td { background: #fef3c7; border: 1px solid #d4a106; font-weight: 800; padding: 7px; font-size: 12px; color: #78350f; }' +
        '  .sign { margin-top: 34px; display: flex; justify-content: space-between; color: #475569; }' +
        '  .sign .line { display: inline-block; width: 170px; border-top: 1px dashed #94a3b8; padding-top: 4px; text-align: center; }' +
        '  .footer-meta { margin-top: 12px; font-size: 9.5px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 6px; display: flex; justify-content: space-between; }' +
        '  @page { size: A4 portrait; margin: 10mm; }' +
        '  @media print { body { padding: 0; } }' +
        '</style></head><body>' +
        '<div class="brand"><h1>' + esc(opt.title || '') + '</h1><span class="sys">سامانه انبار و فروش — فروغ آریا</span></div>' +
        (opt.subTitle ? '<div class="sub">' + esc(opt.subTitle) + '</div>' : '') +
        (meta ? '<div class="chips">' + meta + '</div>' : '') +
        '<table><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody>' + foot + '</table>' +
        '<div class="sign"><span>تحویل‌دهنده: <span class="line"></span></span><span>تأییدکننده: <span class="line"></span></span></div>' +
        '<div class="footer-meta"><span>تاریخ چاپ: ' + esc(opt.printedAt || '') + '</span><span>چاپ‌کننده: ' + esc(opt.printedBy || '') + '</span></div>' +
        '</body></html>';

    // ---------- آیفریم نامرئی — بدون window.open (مسدودکننده پاپ‌آپ اثری ندارد) ----------
    var frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.position = 'fixed';
    frame.style.right = '0';
    frame.style.bottom = '0';
    frame.style.width = '0';
    frame.style.height = '0';
    frame.style.border = '0';
    frame.style.opacity = '0';
    document.body.appendChild(frame);

    var done = false;
    function doPrint() {
        if (done) return;
        done = true;
        try {
            var w = frame.contentWindow;
            w.focus();
            w.print();
        } catch (e) { }
        // بعد از چاپ (یا در هر صورت چند ثانیه بعد) آیفریم پاک شود
        setTimeout(function () { try { frame.remove(); } catch (e) { } }, 15000);
    }
    frame.onload = function () { setTimeout(doPrint, 250); };

    var doc = frame.contentWindow.document;
    doc.open('text/html', 'replace');
    doc.write(html);
    doc.close();
    setTimeout(doPrint, 1200); // احتیاط: اگر onload صدا نزد
};

// =====================================================================
// ساخت Object URL از داده Base64 — برای پیش‌نمایش پیوست‌ها داخل برنامه
// (با توکن گرفته می‌شود و بدون اینکه آدرس توکنی لو برود داخل مودال نمایش داده می‌شود)
// =====================================================================
window.blobUrl = function (base64, contentType) {
    var bin = atob(base64);
    var len = bin.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
    var blob = new Blob([bytes], { type: contentType || 'application/octet-stream' });
    return URL.createObjectURL(blob);
};

// آزادسازی Object URL بعد از بستن پیش‌نمایش
window.revokeBlobUrl = function (url) {
    try { URL.revokeObjectURL(url); } catch (e) { }
};
