using Microsoft.Extensions.Configuration;

namespace Inventory.Client.Services;

// =====================================================================
//  مدیریت متمرکز آدرس‌های API — «تک‌فایل کانفیگ» کلاینت Blazor
//  ---------------------------------------------------------------------
//  منبع واحد تنظیمات: فایل wwwroot/appsettings.json — بخش «ApiEndpoints»
//
//    "ApiEndpoints": {
//      "Default": "Default",                 ← Endpoint پیش‌فرض برای هر ماژولِ بدون نگاشت
//      "Endpoints": {                        ← تعریف سرورها (کلید دلخواه)
//        "Default": { "Name": "سرور اصلی", "BaseUrl": "" },
//        "Paya":    { "Name": "سرور پیا", "BaseUrl": "http://192.168.30.105:8091" }
//      },
//      "Modules": {                          ← نگاشت ماژول → سرور
//        "Projects": "Paya",                 ← ماژول مدیریت پروژه به سرور Paya
//        "Realtime": "Paya"                  ← اتصال بلادرنگ (SignalR) هم به همان
//      }
//    }
//
//  • BaseUrl خالی ("") یعنی «همان مبدأ» — همان آدرسی که برنامه از آن سرو شده
//    (رفتار فعلی پابلیش تکی روی هر سرور — بدون نیاز به هیچ تغییری در فایل).
//  • هر ماژولی که در Modules نباشد، به Endpoint «Default» می‌رود.
//  • کلیدهای ماژول (ثابت کد — در Program.cs به سرویس‌ها متصل‌اند):
//      Auth, Core, Inventory, Sales, Projects, Reports, Finance, Maintenance, Realtime
//  • نکته PWA: این فایل همراه برنامه کش می‌شود — هر تغییر در آن = پابلیش جدید.
// =====================================================================

/// <summary>اطلاعات یک سرور (Endpoint) تعریف‌شده در کانفیگ</summary>
public sealed class ApiEndpointInfo
{
    public string Id { get; set; } = "Default";
    public string Name { get; set; } = "";
    public string BaseUrl { get; set; } = "";

    /// <summary>خالی بودن BaseUrl یعنی «همان مبدأ» — آدرس سروِ فعلی برنامه</summary>
    public bool IsSameOrigin => string.IsNullOrWhiteSpace(BaseUrl);
}

/// <summary>
/// حل‌کنندهٔ مرکزی آدرس API — از appsettings.json خوانده می‌شود و به ازای هر
/// «کلید ماژول» ApiClient مناسبِ همان سرور را می‌سازد. سرویس‌ها (مثل ProjectService)
/// هیچ تغییری نمی‌کنند؛ فقط موقع ثبت در Program.cs کلید ماژول‌شان داده می‌شود.
/// </summary>
public sealed class ApiClientResolver
{
    private readonly Dictionary<string, ApiEndpointInfo> _endpoints = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, string> _moduleMap = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, HttpClient> _httpCache = new(StringComparer.OrdinalIgnoreCase);
    private readonly IAuthState _auth;
    private string _defaultEndpointId = "Default";

    /// <summary>
    /// آدرس «همان مبدأ» — قبل از مقداردهی در Program.cs فال‌بک توسعه است.
    /// با SetSameOrigin مقدار واقعی (origin جاری مرورگر) تزریق می‌شود.
    /// </summary>
    private string _sameOrigin = "http://localhost:5100";

    public ApiClientResolver(IConfiguration config, IAuthState auth)
    {
        _auth = auth;

        var sec = config.GetSection("ApiEndpoints");
        _defaultEndpointId = sec["Default"] ?? "Default";

        // ---------- خواندن تعریف سرورها ----------
        foreach (var epSection in sec.GetSection("Endpoints").GetChildren())
        {
            var ep = new ApiEndpointInfo
            {
                Id = epSection.Key,
                Name = epSection["Name"] ?? epSection.Key,
                BaseUrl = (epSection["BaseUrl"] ?? "").Trim().TrimEnd('/')
            };
            _endpoints[ep.Id] = ep;
        }
        // فال‌بک: اگر فایل/بخش نبود، دقیقاً مثل قبل تک‌سرورِ همان‌مبدأ رفتار می‌کنیم
        if (_endpoints.Count == 0)
            _endpoints["Default"] = new ApiEndpointInfo { Id = "Default", Name = "سرور اصلی", BaseUrl = "" };
        if (!_endpoints.ContainsKey(_defaultEndpointId))
            _defaultEndpointId = "Default";

        // ---------- خواندن نگاشت ماژول → سرور ----------
        foreach (var modSection in sec.GetSection("Modules").GetChildren())
        {
            var target = modSection.Value ?? "";
            if (!string.IsNullOrWhiteSpace(target) && _endpoints.ContainsKey(target))
                _moduleMap[modSection.Key] = target;
        }
    }

    /// <summary>لیست سرورهای تعریف‌شده (برای نمایش/عیب‌یابی/انتخابگر آینده)</summary>
    public IReadOnlyList<ApiEndpointInfo> Endpoints => _endpoints.Values.ToList();

    /// <summary>تزریق آدرس واقعی مبدأ جاری — یک‌بار در Program.cs بعد از خواندن JS</summary>
    public void SetSameOrigin(string origin)
    {
        if (!string.IsNullOrWhiteSpace(origin))
            _sameOrigin = origin.Trim().TrimEnd('/');
    }

    /// <summary>شناسهٔ Endpointِ یک ماژول (با فال‌بک به Endpoint پیش‌فرض)</summary>
    public string EndpointIdOf(string moduleKey)
        => _moduleMap.TryGetValue(moduleKey ?? "", out var id) ? id : _defaultEndpointId;

    /// <summary>آدرس پایهٔ نهاییِ یک ماژول — BaseUrl خالی یعنی «همان مبدأ»</summary>
    public string BaseUrlOf(string moduleKey)
    {
        var id = EndpointIdOf(moduleKey);
        var ep = _endpoints.TryGetValue(id, out var e) ? e : _endpoints[_defaultEndpointId];
        return ep.IsSameOrigin ? _sameOrigin : ep.BaseUrl;
    }

    /// <summary>نام نمایشی سرورِ یک ماژول (برای تشخیص روی UI — «متصل به: سرور پیا»)</summary>
    public string EndpointNameOf(string moduleKey)
    {
        var id = EndpointIdOf(moduleKey);
        return _endpoints.TryGetValue(id, out var e) ? e.Name : "";
    }

    /// <summary>اسنپ‌شات ApiOptions برای یک ماژول (مصرف‌کننده‌هایی که مستقیم ApiOptions تزریق می‌کنند)</summary>
    public ApiOptions SnapshotOf(string moduleKey) => new()
    {
        BaseUrl = BaseUrlOf(moduleKey),
        ModuleKey = moduleKey,
        EndpointName = EndpointNameOf(moduleKey)
    };

    /// <summary>
    /// ساخت ApiClient اختصاصی یک ماژول — توکن همان نشست فعلی است (در شبکه‌هایی که
    /// سرورها کلید JWT یکسان دارند — مثل استقرارهای همین سامانه — بدون لاگین مجدد کار می‌کند).
    /// </summary>
    public IApiClient For(string moduleKey)
    {
        var baseUrl = BaseUrlOf(moduleKey);
        var http = _httpCache.TryGetValue(baseUrl, out var cached) ? cached : (_httpCache[baseUrl] = new HttpClient());
        return new ApiClient(http, SnapshotOf(moduleKey), _auth);
    }
}
