using Inventory.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Controllers;

/// <summary>تاریخچهٔ تغییرات (لاگ ِ) هر پروژه — مشاهده با مجوز Projects.Read</summary>
[Route("api/projectlogs")]
public class ProjectLogsController : RbacControllerBase
{
    public ProjectLogsController(AppDbContext db) : base(db) { }

    /// <summary>لیست لاگ‌های یک پروژه — جدیدترین اول</summary>
    [HttpGet("{projectId:int}")]
    public async Task<IActionResult> ForProject(int projectId)
    {
        if (await ForbiddenUnlessAsync("Projects", "Read") is { } forbid) return forbid;

        var exists = await Db.ProjectEntryExits.AnyAsync(p => p.Id == projectId && !p.IsDelete);
        if (!exists) return NotFound(new { message = "پروژه پیدا نشد." });

        var logs = await Db.ProjectLogs.AsNoTracking()
            .Where(l => l.ProjectId == projectId)
            .OrderByDescending(l => l.Id)
            .Take(500)
            .ToListAsync();
        return Ok(logs);
    }
}
