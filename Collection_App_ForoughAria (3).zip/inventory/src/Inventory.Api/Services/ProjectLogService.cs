using Inventory.Api.Data;


namespace Inventory.Api.Services;

/// <summary>
/// کارخانهٔ ثبت لاگ ممیزی پروژه — متد ثابت سبک، بدون نیاز به دی‌آی جدید:
/// در کنترلرها بعد از تغییر موفق صدا زده می‌شود (همراه همان SaveChanges دیتابیس اصلی).
/// </summary>
public static class ProjectLogService
{
    /// <summary>ثبت یک رویداد روی پروژه — فقط رکورد را به کانتکست اضافه می‌کند (SaveChanges توسط صدا‌زننده انجام شود).</summary>
    public static void Add(AppDbContext db, ProjectEntryExit p, string action, string actionFa, string? detail, int actorUserId, string actorName)
    {
        db.ProjectLogs.Add(new ProjectLog
        {
            ProjectId = p.Id,
            ProjectCode = p.CodeProject ?? "",
            Action = action,
            ActionFa = actionFa,
            Detail = string.IsNullOrWhiteSpace(detail) ? null : detail.Trim(),
            ActorUserId = actorUserId,
            ActorName = actorName,
            At = DateTime.Now
        });
    }

    /// <summary>خلاصه استاندارد اطلاعات پروژه برای لاگ</summary>
    public static string SummaryOf(ProjectEntryExit p)
        => $"کد «{p.CodeProject}» — نام «{p.ProjectName}» — سریال {p.SerialNumber}";
}
