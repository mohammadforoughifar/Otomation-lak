using Inventory.Api.Data;
using Inventory.Api.Services;
using Inventory.Shared.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Controllers;

/// <summary>پیوست‌های پروژه — رمزنگاری‌شده روی دیسک سرور. ماژول دسترسی: ProjectAttach</summary>
[Route("api/projectattach")]
public class ProjectAttachController : RbacControllerBase
{
    private const string Module = "ProjectAttach";
    private readonly IProjectFileProtection _protect;

    public ProjectAttachController(AppDbContext db, IProjectFileProtection protect) : base(db)
        => _protect = protect;

    private string? myDisplay;

    /// <summary>نام فارسی نوع پیوست (۱=قرارداد،۲=مدارک فنی،۳=تاییدیه تحویل،۴=سایر)</summary>
    private static string TypeNameOf(int t) => t switch { 1 => "قرارداد", 2 => "مدارک فنی", 3 => "تاییدیه تحویل", 4 => "سایر", _ => "سایر" };

    private static string DisplayOf(User u)
    {
        var full = $"{u.FirstName} {u.LastName}".Trim();
        return string.IsNullOrWhiteSpace(full) ? u.Username : full;
    }

    /// <summary>لیست پیوست‌های یک پروژه</summary>
    [HttpGet("project/{projectId:int}")]
    public async Task<IActionResult> GetForProject(int projectId)
    {
        if (await ForbiddenUnlessAsync(Module, "Read") is { } forbid) return forbid;

        var list = await Db.ProjectAttaches.AsNoTracking()
            .Include(a => a.User)
            .Where(a => a.ProjectId == projectId && !a.IsDelete)
            .OrderByDescending(a => a.Id)
            .ToListAsync();

        var result = list.Select(a => new ProjectAttachDto
        {
            Id = a.Id,
            FileName = SafeDecrypt(a.OriginalFileNameEncrypted),
            FileSize = a.FileSize,
            Type = a.Type,
            DateSabt = a.DateSabt,
            ProjectId = a.ProjectId,
            UserName = a.User is null ? null : DisplayOf(a.User)
        }).ToList();
        return Ok(result);
    }

    /// <summary>آپلود یک یا چند فایل برای یک پروژه (multipart)</summary>
    [RequestFormLimits(MultipartBodyLengthLimit = 250_000_000)]
    [RequestSizeLimit(250_000_000)]
    [HttpPost]
    public async Task<IActionResult> Upload(
        [FromForm] int projectId,
        [FromForm] int type,
        [FromForm] List<IFormFile> files,
        [FromForm] string? mode,
        CancellationToken ct)
    {
        if (await ForbiddenUnlessAsync(Module, "Create") is { } forbid) return forbid;

        var project = await Db.ProjectEntryExits.AsNoTracking()
            .Where(p => p.Id == projectId && !p.IsDelete)
            .Select(p => new { p.Id, p.CodeProject })
            .FirstOrDefaultAsync(ct);
        if (projectId <= 0 || project is null)
            return BadRequest(new { message = "پروژه معتبر نیست." });
        if (files is null || files.Count == 0)
            return BadRequest(new { message = "هیچ فایلی ارسال نشده است." });
        if (type is < 0) type = 0;

        // حالت مستندات: تصویر پذیرفته نیست (درخواست کاربر) — حالت تصویر: فقط تصویر
        var isImageExt = new Func<string, bool>(x => ProjectFileProtection.KindFolderOf(x) == "تصاویر");
        if (string.Equals(mode, "doc", StringComparison.OrdinalIgnoreCase)
            && files.Any(f => isImageExt(Path.GetExtension(f.FileName) ?? "")))
            return BadRequest(new { message = "در بخش مستندات فایل تصویری آپلود نمی‌شود — لطفاً آن را در بخش «تصاویر پروژه» بارگذاری کنید." });
        if (string.Equals(mode, "image", StringComparison.OrdinalIgnoreCase)
            && files.Any(f => !isImageExt(Path.GetExtension(f.FileName) ?? "")))
            return BadRequest(new { message = "در بخش تصاویر فقط فایل تصویری (jpg، png و…) پذیرفته می‌شود." });

        var uploaded = 0;
        foreach (var file in files)
        {
            if (file.Length == 0) continue;

            var originalName = Path.GetFileName(file.FileName); // حذف مسیر احتمالی
            var ext = Path.GetExtension(originalName);

            // هر پروژه پوشهٔ خودش (کد پروژه) و داخل آن تصاویر از مستندات جدا — درخواست کاربر
            var subFolder = $"{ProjectFileProtection.SanitizeSegment(project.CodeProject)}/{ProjectFileProtection.KindFolderOf(ext)}";

            string stored;
            await using (var src = file.OpenReadStream())
                stored = await _protect.EncryptAndStoreAsync(src, subFolder, ct);

            Db.ProjectAttaches.Add(new ProjectAttach
            {
                OriginalFileNameEncrypted = _protect.EncryptString(originalName),
                StoredFileName = stored,
                Extension = ext,
                FileSize = file.Length,
                DateSabt = DateTime.Now,
                Type = type,
                UserId = MyUserId,
                ProjectId = projectId
            });
            uploaded++;
            ProjectLogService.Add(Db, new ProjectEntryExit { Id = projectId, CodeProject = project.CodeProject },
                "AttachAdd", "آپلود پیوست", $"«{originalName}» (نوع {TypeNameOf(type)})",
                MyUserId, myDisplay ??= await MyDisplayNameAsync());
        }

        if (uploaded == 0)
            return BadRequest(new { message = "فایل‌های ارسالی خالی هستند." });

        await Db.SaveChangesAsync(ct);
        return Ok(new { uploaded });
    }

    /// <summary>دانلود — رمزگشایی محتوا و بازگردانی با نام اصلی فایل.
    /// با ?inline=1 بدون Content-Disposition برمی‌گردد تا مرورگر داخل خودش باز کند (پیش‌نمایش PDF/تصویر/متن).</summary>
    [HttpGet("{id:int}/download")]
    public async Task<IActionResult> Download(int id, [FromQuery] bool inline, CancellationToken ct)
    {
        if (await ForbiddenUnlessAsync(Module, "Read") is { } forbid) return forbid;

        var a = await Db.ProjectAttaches.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDelete, ct);
        if (a is null) return NotFound(new { message = "پیوست پیدا نشد." });

        var fileName = SafeDecrypt(a.OriginalFileNameEncrypted);

        MemoryStream plain;
        try
        {
            plain = await _protect.LoadAndDecryptAsync(a.StoredFileName, ct);
        }
        catch (FileNotFoundException)
        {
            return NotFound(new { message = "فایل روی سرور پیدا نشد." });
        }
        catch (Exception)
        {
            return BadRequest(new { message = "رمزگشایی فایل انجام نشد — فایل خراب است یا کلید رمز تغییر کرده است." });
        }

        var mime = ContentTypeOf(a.Extension);
        if (inline) return File(plain, mime); // بدون نام فایل دانلودی — مرورگر داخل خودش (پیش‌نمایش) باز می‌کند
        return File(plain, mime, fileName);
    }

    /// <summary>پیش‌نمایش به‌صورت Base64 برای رندر داخل مودال (با محدودیت حجم تا جلوگیری از فشار حافظه).</summary>
    [HttpGet("{id:int}/preview")]
    public async Task<IActionResult> Preview(int id, CancellationToken ct)
    {
        if (await ForbiddenUnlessAsync(Module, "Read") is { } forbid) return forbid;

        var a = await Db.ProjectAttaches.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDelete, ct);
        if (a is null) return NotFound(new { message = "پیوست پیدا نشد." });
        if (a.FileSize > 15_000_000)
            return BadRequest(new { message = "حجم فایل برای پیش‌نمایش زیاد است — از دانلود استفاده کنید." });

        MemoryStream plain;
        try { plain = await _protect.LoadAndDecryptAsync(a.StoredFileName, ct); }
        catch (FileNotFoundException) { return NotFound(new { message = "فایل روی سرور پیدا نشد." }); }
        catch (Exception) { return BadRequest(new { message = "رمزگشایی فایل انجام نشد — فایل خراب است یا کلید رمز تغییر کرده است." }); }

        return Ok(new
        {
            fileName = SafeDecrypt(a.OriginalFileNameEncrypted),
            mime = ContentTypeOf(a.Extension),
            ext = (a.Extension ?? "").ToLowerInvariant(),
            base64 = Convert.ToBase64String(plain.ToArray())
        });
    }

    /// <summary>حذف — رکورد نرم + حذف فیزیکی فایل رمزنگاری‌شده</summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        if (await ForbiddenUnlessAsync(Module, "Delete") is { } forbid) return forbid;

        var a = await Db.ProjectAttaches.FirstOrDefaultAsync(x => x.Id == id && !x.IsDelete);
        if (a is null) return NotFound(new { message = "پیوست پیدا نشد." });

        a.IsDelete = true;
        try { _protect.Delete(a.StoredFileName); } catch { /* ممکن است از قبل حذف شده باشد */ }
        var projCode = await Db.ProjectEntryExits.AsNoTracking()
            .Where(p => p.Id == a.ProjectId).Select(p => p.CodeProject).FirstOrDefaultAsync() ?? "";
        ProjectLogService.Add(Db, new ProjectEntryExit { Id = a.ProjectId, CodeProject = projCode },
            "AttachDelete", "حذف پیوست", $"«{SafeDecrypt(a.OriginalFileNameEncrypted)}»",
            MyUserId, await MyDisplayNameAsync());
        await Db.SaveChangesAsync();
        return Ok(new { ok = true });
    }

    // ==================== کمکی ====================

    private string SafeDecrypt(string encrypted)
    {
        try { return _protect.DecryptString(encrypted); }
        catch { return "[نام فایل قابل رمزگشایی نیست]"; }
    }

    private static string ContentTypeOf(string? ext) => (ext ?? "").ToLowerInvariant() switch
    {
        ".pdf" => "application/pdf",
        ".png" => "image/png",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".gif" => "image/gif",
        ".zip" => "application/zip",
        ".rar" => "application/vnd.rar",
        ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".txt" => "text/plain",
        ".csv" => "text/csv",
        ".dwg" => "application/acad",
        _ => "application/octet-stream"
    };
}
